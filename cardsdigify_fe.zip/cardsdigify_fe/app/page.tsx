
import Login from './components/Login'

export default function Home() {
  return (
    <main>
      <Login/>
    </main>
  )
}
