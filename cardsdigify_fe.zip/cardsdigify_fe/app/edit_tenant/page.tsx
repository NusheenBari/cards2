import EditTenant from "../components/AllTenants/EditTenant";

export default function TenantEditPage() {
  return (
    <div>
      <EditTenant/>
    </div>
  )
}
