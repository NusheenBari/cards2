import Dashboard from "../components/dashboard/Dashboard"

const page = () => {
  return (
    <div>
        <Dashboard/>
    </div>
  )
}

export default page