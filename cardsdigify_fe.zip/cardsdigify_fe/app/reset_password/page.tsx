import ForgotPass from "../components/ForgotPass"

const page = () => {
  return (
    
    <>
        <ForgotPass/>
    </>
    
  )
}

export default page