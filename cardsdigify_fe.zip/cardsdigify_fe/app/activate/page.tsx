
function page() {
  return (
    <div>
      Activation Page
    </div>
  )
}

export default page
